//
//  ViewController.swift
//  Quiz_19013345
//
//  Created by day4 on 21/1/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
}

